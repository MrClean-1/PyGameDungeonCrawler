This game can and should be run via the main.py function.

Packed textures can be ignored as they were not ever implemented

WASD to move

Arrow keys to shoot

Enemies sometimes drop hears on death, pick them up to regain health points

There is a weird sRGB error code that sometimes happens with libPNG
It's a PyGame issue and doesn't appear to cause any sprite/display issues within the game
